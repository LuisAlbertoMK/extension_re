// background.js — service worker: screenshots + clicks humanizados via chrome.debugger
let debuggeeTabId = null;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const cmd = (tabId, method, params) => new Promise((res, rej) =>
  chrome.debugger.sendCommand({ tabId }, method, params, () =>
    chrome.runtime.lastError ? rej(chrome.runtime.lastError.message) : res()));

async function doClick({ tabId, x, y, path = [], hold = 60 }) {
  const mv = (px, py) => cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x: px, y: py });
  for (const p of path) { await mv(p.x, p.y); await sleep(p.d || 10); }
  await mv(x, y);
  await sleep(20 + Math.random() * 40);
  await cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
  await sleep(hold);
  await cmd(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_TAB_ID') { sendResponse({ tabId: sender.tab?.id }); return true; }

  if (msg.type === 'CAPTURE_SCREENSHOT') {
    chrome.tabs.captureVisibleTab(null, { format: 'png' }, (dataUrl) => {
      if (chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
      else sendResponse({ dataUrl });
    });
    return true;
  }

  if (msg.type === 'DEBUGGER_CLICK') {
    const run = () => doClick(msg).then(() => sendResponse({ ok: true })).catch(e => sendResponse({ error: String(e) }));
    if (debuggeeTabId !== msg.tabId) {
      chrome.debugger.attach({ tabId: msg.tabId }, '1.3', () => {
        const err = chrome.runtime.lastError;
        if (err && !/already attached/i.test(err.message)) { sendResponse({ error: err.message }); return; }
        debuggeeTabId = msg.tabId; run();
      });
    } else run();
    return true;
  }

  if (msg.type === 'DEBUGGER_DETACH') {
    if (debuggeeTabId) {
      chrome.debugger.detach({ tabId: debuggeeTabId }, () => { void chrome.runtime.lastError; debuggeeTabId = null; sendResponse({ ok: true }); });
      return true;
    }
    sendResponse({ ok: true });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === debuggeeTabId) { chrome.debugger.detach({ tabId }, () => { void chrome.runtime.lastError; }); debuggeeTabId = null; }
});
