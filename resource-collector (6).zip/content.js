// Resource Collector — detecta burbujas blancas y clasifica el recurso por color interior
const CFG = {
  meat: true, wood: true, gold: true, stone: true,
  cycMin: 25000, cycMax: 40000,        // ms entre escaneos
  whiteMin: 243,                       // umbral de "blanco" de la burbuja
  wMin: 30, wMax: 65, hMin: 30, hMax: 70, // tamaño burbuja (px de screenshot)
  minPx: 40,                           // píxeles mínimos del color del recurso
  mTop: 0.09, mBottom: 0.14, mLeft: 0.07, mRight: 0.08, // zonas UI excluidas (fracción de la ventana)
  jitter: 3, gapMin: 700, gapMax: 1800, // jitter y pausa entre clicks (ms)
  maxAttempts: 3,
  option: 0,                           // 0=5min(arriba-izq) 1=1h 2=4h 3=8h
  selMin: 10000, selMax: 40000,        // espera antes de elegir el tiempo (ms)
  btnWMin: 80, btnWMax: 140, btnHMin: 20, btnHMax: 40 // botón "Elegir" (px de screenshot)
};
let running = false, timer = null, tabId = null, status = 'detenido';
let mouse = { x: innerWidth / 2 + Math.random() * 200 - 100, y: innerHeight / 2 };
const stats = { meat: 0, wood: 0, gold: 0, stone: 0, cycles: 0, found: 0, chosen: 0 };
let dialogTries = 0;
const attempts = new Map();

const rand = (a, b) => a + Math.random() * (b - a);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const hasCanvas = () => !!document.querySelector('canvas');
const loadImg = url => new Promise(r => { const i = new Image(); i.onload = () => r(i); i.src = url; });

function classify(r, g, b) {
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), v = mx / 255, d = mx - mn;
  const sat = mx ? d / mx : 0;
  if (sat < 0.18) return (v >= 0.4 && v <= 0.95) ? 'stone' : null;
  if (sat < 0.3 || v < 0.4) return null;
  let h;
  if (d === 0) return null;
  if (mx === r) h = 60 * (((g - b) / d + 6) % 6);
  else if (mx === g) h = 60 * ((b - r) / d + 2);
  else h = 60 * ((r - g) / d + 4);
  if (h <= 13 || h >= 340) return v >= 0.55 ? 'meat' : null;
  if (h >= 33 && h <= 62) return 'gold';
  if (h > 13 && h < 33) return v <= 0.86 ? 'wood' : null;
  return null;
}

function detect(img) {
  const W = img.width, H = img.height, s = W / innerWidth;
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(img, 0, 0);
  const d = ctx.getImageData(0, 0, W, H).data;
  const mx0 = CFG.mLeft * W, mx1 = W - CFG.mRight * W, my0 = CFG.mTop * H, my1 = H - CFG.mBottom * H;
  const white = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) {
    const p = i * 4;
    if (d[p] >= CFG.whiteMin && d[p + 1] >= CFG.whiteMin && d[p + 2] >= CFG.whiteMin) white[i] = 1;
  }

  // una pasada: E = píxeles de adelgazado de la máscara (0, 1, 2)
  function pass(E) {
    let mask = white;
    for (let k = 0; k < E; k++) {
      const nx = new Uint8Array(W * H);
      for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
        const i = y * W + x;
        if (mask[i] && mask[i - 1] && mask[i + 1] && mask[i - W] && mask[i + W]) nx[i] = 1;
      }
      mask = nx;
    }
    const seen = new Uint8Array(W * H), q = new Int32Array(W * H), items = [], btns = [], frags = [], rejects = [];
    for (let st = 0; st < W * H; st++) {
      if (!mask[st] || seen[st]) continue;
      let h = 0, t = 0, minX = W, maxX = 0, minY = H, maxY = 0;
      q[t++] = st; seen[st] = 1;
      while (h < t) {
        const i = q[h++], x = i % W, y = (i / W) | 0;
        if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
        if (x > 0 && mask[i - 1] && !seen[i - 1]) { seen[i - 1] = 1; q[t++] = i - 1; }
        if (x < W - 1 && mask[i + 1] && !seen[i + 1]) { seen[i + 1] = 1; q[t++] = i + 1; }
        if (y > 0 && mask[i - W] && !seen[i - W]) { seen[i - W] = 1; q[t++] = i - W; }
        if (y < H - 1 && mask[i + W] && !seen[i + W]) { seen[i + W] = 1; q[t++] = i + W; }
      }
      minX = Math.max(0, minX - E); maxX = Math.min(W - 1, maxX + E); minY = Math.max(0, minY - E); maxY = Math.min(H - 1, maxY + E);
      const w = maxX - minX + 1, hh = maxY - minY + 1, fill = t / (w * hh), ratio = hh / w;
      if (E === 0 && w >= CFG.btnWMin && w <= CFG.btnWMax && hh >= CFG.btnHMin && hh <= CFG.btnHMax && fill > 0.5 && ratio < 0.4) {
        btns.push({ x: (minX + w / 2) / s, y: (minY + hh / 2) / s, w: w / s, h: hh / s }); continue;
      }
      if (t >= (E ? 20 : 40) && w <= CFG.wMax && hh <= CFG.hMax) frags.push({ minX, maxX, minY, maxY, t });
    }
    // unir fragmentos (el ícono puede partir el fondo blanco) sin superar el tamaño máximo de burbuja
    frags.sort((a, b) => b.t - a.t); frags.length = Math.min(frags.length, 1500);
    const groups = [], G = 3;
    for (const f of frags) {
      let done = false;
      for (const g of groups) {
        const ox = Math.min(f.maxX, g.maxX) - Math.max(f.minX, g.minX) + 1, oy = Math.min(f.maxY, g.maxY) - Math.max(f.minY, g.minY) + 1;
        const mw = Math.min(f.maxX - f.minX, g.maxX - g.minX) + 1, mh = Math.min(f.maxY - f.minY, g.maxY - g.minY) + 1;
        const gx = Math.max(f.minX - g.maxX, g.minX - f.maxX), gy = Math.max(f.minY - g.maxY, g.minY - f.maxY);
        // cerca: se tocan, o están alineados (el ícono del medio los separa) con hueco <= 28px
        if ((gx <= G && gy <= G) || (ox >= 0.6 * mw && gy <= 28) || (oy >= 0.6 * mh && gx <= 28)) {
          const nminX = Math.min(g.minX, f.minX), nmaxX = Math.max(g.maxX, f.maxX),
                nminY = Math.min(g.minY, f.minY), nmaxY = Math.max(g.maxY, f.maxY);
          if (nmaxX - nminX + 1 <= CFG.wMax && nmaxY - nminY + 1 <= CFG.hMax) {
            g.minX = nminX; g.maxX = nmaxX; g.minY = nminY; g.maxY = nmaxY; g.t += f.t; done = true; break;
          }
        }
      }
      if (!done) groups.push({ ...f });
    }
    for (const g of groups) {
      const w = g.maxX - g.minX + 1, hh = g.maxY - g.minY + 1, fill = g.t / (w * hh), ratio = hh / w;
      const cx = g.minX + w / 2, cy = g.minY + hh / 2;
      if (cx < mx0 || cx > mx1 || cy < my0 || cy > my1) continue;
      const rj = why => rejects.push({ x: cx / s, y: cy / s, w: w / s, h: hh / s, why });
      if (w < CFG.wMin || w > CFG.wMax || hh < CFG.hMin || hh > CFG.hMax) { if (w >= 20 && hh >= 20) rj('tam ' + w + 'x' + hh); continue; }
      if (fill < 0.12 || fill > 0.92 || ratio < 0.8 || ratio > 1.6) { rj('forma ' + fill.toFixed(2) + '/' + ratio.toFixed(1)); continue; }
      // forma de burbuja: las dos esquinas superiores (con 6px de margen) deben ser blancas
      const wh = (x, y) => { for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < W && yy < H && white[yy * W + xx]) return true; } return false; };
      if (!wh(g.minX + 6, g.minY + 6) || !wh(g.maxX - 6, g.minY + 6)) { rj('esquinas'); continue; }
      const cnt = { meat: 0, wood: 0, gold: 0, stone: 0 };
      for (let y = g.minY; y <= g.maxY; y++) for (let x = g.minX; x <= g.maxX; x++) {
        if (white[y * W + x]) continue;
        const p = (y * W + x) * 4, k = classify(d[p], d[p + 1], d[p + 2]);
        if (k) cnt[k]++;
      }
      let best = null, bn = 0;
      for (const k in cnt) if (cnt[k] > bn) { bn = cnt[k]; best = k; }
      if (!best || bn < CFG.minPx) { rj('color ' + JSON.stringify(cnt)); continue; }
      items.push({ type: best, x: cx / s, y: cy / s, w: w / s, h: hh / s, n: bn });
    }
    return { items, btns, rejects };
  }

  let items = [], btns = [], rej = [];
  for (const E of [0, 1, 2]) {
    const r = pass(E);
    if (E === 0) btns = r.btns;
    rej.push(...r.rejects);
    for (const it of r.items) if (!items.some(o => Math.hypot(o.x - it.x, o.y - it.y) < it.w * 0.6)) items.push(it);
  }
  // diálogo: >=3 botones "Elegir" en cuadrícula 2x2
  let dialog = null;
  if (btns.length >= 3) {
    btns.sort((a, b) => a.y - b.y);
    const top = btns.filter(b => b.y <= btns[0].y + 30).sort((a, b) => a.x - b.x);
    const bot = btns.filter(b => b.y > btns[0].y + 30).sort((a, b) => a.x - b.x);
    if (top.length >= 1 && bot.length >= 1) {
      const row = CFG.option >= 2 ? bot : top;
      dialog = { target: row[CFG.option % 2] || null, btns };
    }
  }
  rej = rej.filter(r => !items.some(o => Math.hypot(o.x - r.x, o.y - r.y) < r.w * 0.6));
  return { items: dialog ? [] : items, dialog, rejects: rej.slice(0, 40) };
}

async function scan() {
  const r = await chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT' });
  if (!r || r.error) { console.error('[Res] captura:', r && r.error); return { items: [], dialog: null, rejects: [] }; }
  return detect(await loadImg(r.dataUrl));
}

function bezier(from, to) {
  const n = Math.round(rand(8, 14)), dx = to.x - from.x, dy = to.y - from.y, dist = Math.hypot(dx, dy) || 1;
  const off = rand(-0.2, 0.2) * dist;
  const cx = from.x + dx / 2 - (dy / dist) * off, cy = from.y + dy / 2 + (dx / dist) * off, pts = [];
  for (let i = 1; i <= n; i++) {
    let t = i / n; t = t * t * (3 - 2 * t); const u = 1 - t;
    pts.push({ x: Math.round(u * u * from.x + 2 * u * t * cx + t * t * to.x),
               y: Math.round(u * u * from.y + 2 * u * t * cy + t * t * to.y), d: Math.round(rand(6, 20)) });
  }
  return pts;
}

async function humanClick(it) {
  if (!tabId) tabId = (await chrome.runtime.sendMessage({ type: 'GET_TAB_ID' }))?.tabId;
  if (!tabId) return false;
  const j = CFG.jitter;
  const x = Math.round(it.x + rand(-j, j)), y = Math.round(it.y + rand(-j, j));
  const res = await chrome.runtime.sendMessage({
    type: 'DEBUGGER_CLICK', tabId, x, y, path: bezier(mouse, { x, y }), hold: Math.round(rand(40, 140))
  });
  if (res && res.error) { console.error('[Res] click:', res.error); return false; }
  mouse = { x, y }; return true;
}

async function wait(ms, label) {
  const end = Date.now() + ms;
  while (running && Date.now() < end) {
    if (label) status = `${label} (${Math.ceil((end - Date.now()) / 1000)}s)`;
    await sleep(Math.min(500, Math.max(0, end - Date.now())));
  }
}

async function chooseTime() {
  await wait(rand(CFG.selMin, CFG.selMax), 'eligiendo tiempo en');
  if (!running) return;
  const r = await scan();
  if (!r.dialog) return;                         // ya se cerró
  if (!r.dialog.target) { dialogTries = 99; return; }
  if (await humanClick(r.dialog.target)) { stats.chosen++; }
  await sleep(rand(800, 1500));
}

function nextItem(items) {
  const cand = items.filter(it => {
    const key = Math.round(it.x / 14) + ',' + Math.round(it.y / 14), now = Date.now();
    let a = attempts.get(key);
    if (a && now - a.t > 300000) { attempts.delete(key); a = null; }
    if (a && a.n < CFG.maxAttempts && now - a.t > 60000) a.n = 0;
    return CFG[it.type] && !(a && (now - a.t < 8000 || a.n >= CFG.maxAttempts));
  });
  return cand.length ? cand[Math.floor(Math.random() * cand.length)] : null;
}

async function cycle() {
  let clicked = 0; dialogTries = 0; stats.cycles++;
  for (let iter = 0; iter < 40 && running; iter++) {
    status = 'escaneando';
    const r = await scan();
    if (iter === 0) stats.found = r.items.length;
    if (r.dialog) {
      if (++dialogTries > 3) { stop('no logro elegir el tiempo (revisa Calibrar)'); return clicked; }
      await chooseTime(); continue;
    }
    const it = nextItem(r.items);
    if (!it) break;
    await sleep(rand(CFG.gapMin, CFG.gapMax));
    if (await humanClick(it)) {
      stats[it.type]++; clicked++;
      const key = Math.round(it.x / 14) + ',' + Math.round(it.y / 14), a = attempts.get(key);
      attempts.set(key, { n: (a ? a.n : 0) + 1, t: Date.now() });
      await sleep(rand(1200, 2200));            // deja que abra el diálogo
    }
  }
  if (clicked) chrome.runtime.sendMessage({ type: 'DEBUGGER_DETACH' }).catch(() => {});
  return clicked;
}

async function tick() {
  if (!running) return;
  try {
    if (document.hidden) status = 'pausado (tab oculto)';
    else { const n = await cycle(); if (running) status = n ? `recolectó ${n}` : 'esperando recursos'; }
  } catch (e) { console.error('[Res]', e); }
  if (running) timer = setTimeout(tick, rand(CFG.cycMin, CFG.cycMax));
}

function start() { if (running) return; running = true; status = 'iniciando'; tick(); }
function stop(msg) {
  running = false; clearTimeout(timer); status = msg || 'detenido';
  chrome.runtime.sendMessage({ type: 'DEBUGGER_DETACH' }).catch(() => {});
}

async function calibrate() {
  const { items, dialog, rejects = [] } = await scan();
  const o = document.createElement('canvas'); o.width = innerWidth; o.height = innerHeight;
  Object.assign(o.style, { position: 'fixed', left: 0, top: 0, zIndex: 2147483647, pointerEvents: 'none' });
  const g = o.getContext('2d');
  g.strokeStyle = 'rgba(255,0,0,.6)';
  g.strokeRect(CFG.mLeft * innerWidth, CFG.mTop * innerHeight, innerWidth * (1 - CFG.mLeft - CFG.mRight), innerHeight * (1 - CFG.mTop - CFG.mBottom));
  g.lineWidth = 2; g.font = 'bold 13px sans-serif';
  const col = { meat: '#f44', wood: '#a63', gold: '#fc0', stone: '#aaa' };
  const tag = (x, y, txt, c) => { g.fillStyle = '#000'; g.fillRect(x, y - 15, 54, 14); g.fillStyle = c; g.fillText(txt, x + 2, y - 4); };
  items.forEach(t => { g.strokeStyle = col[t.type]; g.strokeRect(t.x - t.w / 2, t.y - t.h / 2, t.w, t.h); tag(t.x - t.w / 2, t.y - t.h / 2, t.type, '#fff'); });
  g.lineWidth = 1; g.setLineDash([4, 3]); g.font = '10px sans-serif';
  rejects.forEach(t => { g.strokeStyle = '#ccc'; g.strokeRect(t.x - t.w / 2, t.y - t.h / 2, t.w, t.h); const tx = t.why.slice(0, 28), tw = g.measureText(tx).width + 4; g.fillStyle = 'rgba(0,0,0,.75)'; g.fillRect(t.x + t.w / 2 + 2, t.y - 6, tw, 12); g.fillStyle = '#fff'; g.fillText(tx, t.x + t.w / 2 + 4, t.y + 4); });
  g.setLineDash([]); g.lineWidth = 2; g.font = 'bold 13px sans-serif';
  if (dialog) dialog.btns.forEach(b => {
    const isT = dialog.target === b; g.strokeStyle = isT ? '#0f0' : '#08f';
    g.strokeRect(b.x - b.w / 2, b.y - b.h / 2, b.w, b.h); tag(b.x - b.w / 2, b.y - b.h / 2, isT ? 'ELEGIR' : 'boton', isT ? '#0f0' : '#8cf');
  });
  document.body.appendChild(o); setTimeout(() => o.remove(), 7000);
  return { n: items.length, dialog: !!dialog };
}

chrome.runtime.onMessage.addListener((m, s, send) => {
  if (!hasCanvas()) return;
  if (m.type === 'STATUS') send({ running, status, stats, cfg: CFG });
  else if (m.type === 'TOGGLE') { running ? stop() : start(); send({ running }); }
  else if (m.type === 'UPDATE_CONFIG') { Object.assign(CFG, m.config); send({ ok: true }); }
  else if (m.type === 'CALIBRATE') { calibrate().then(r => send(r)); return true; }
});
