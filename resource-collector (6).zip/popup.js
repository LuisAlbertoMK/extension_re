const $ = id => document.getElementById(id);
const NUM = ['cycMin','cycMax','wMin','wMax','selMin','selMax','option'], RES = ['meat','wood','gold','stone'];
async function send(m) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try { return await chrome.tabs.sendMessage(tab.id, m); } catch { return null; }
}
let filled = false;
async function refresh() {
  const r = await send({ type: 'STATUS' });
  if (!r) { $('st').textContent = 'sin conexión (recarga la página)'; return; }
  $('st').textContent = r.status; $('cy').textContent = r.stats.cycles; $('ch').textContent = r.stats.chosen; $('fd').textContent = r.stats.found;
  RES.forEach(k => $(k).textContent = r.stats[k]);
  $('toggle').textContent = r.running ? '⏹ Detener' : '▶ Iniciar';
  $('toggle').className = r.running ? 'stop' : 'start';
  if (!filled) { NUM.forEach(f => $(f).value = r.cfg[f]); RES.forEach(k => $(k + '_c').checked = r.cfg[k]); filled = true; }
}
$('toggle').onclick = async () => { await send({ type: 'TOGGLE' }); refresh(); };
$('cal').onclick = async () => { const r = await send({ type: 'CALIBRATE' }); if (r) $('st').textContent = r.dialog ? 'diálogo detectado' : `calibrado: ${r.n} burbujas`; };
$('apply').onclick = async () => {
  const config = {}; NUM.forEach(f => config[f] = Number($(f).value)); RES.forEach(k => config[k] = $(k + '_c').checked);
  await send({ type: 'UPDATE_CONFIG', config });
};
setInterval(refresh, 1000); refresh();
